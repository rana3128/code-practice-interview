1. This application required node version > 14
2. Change the input variable in "index.js" from line number 1 to 4 corrosponding meaning mentioned in comment
3. run project with command "node index.js"