module.exports = {
    EMPTY: 0,
    CREATURE: 1,
    ZOMBIE_START: 2,
    ZOMBIE_END: 3
}